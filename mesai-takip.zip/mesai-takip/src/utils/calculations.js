export function calcHourlyRate(monthlySalary, dailyWorkHours) {
  return monthlySalary / (30 * dailyWorkHours);
}

export function calcOvertimePay(dateStr, hours, settings) {
  const date = new Date(dateStr);
  const day = date.getDay(); // 0=Paz, 6=Cmt
  const hourlyRate = calcHourlyRate(settings.monthlySalary, settings.dailyWorkHours);
  let multiplier = settings.weekdayMultiplier;
  if (day === 6) multiplier = settings.saturdayMultiplier;
  if (day === 0) multiplier = settings.sundayMultiplier;
  return hours * hourlyRate * multiplier;
}

export function calcMonthSummary(year, month, attendance, settings) {
  let totalOvertimeHours = 0;
  let totalOvertimePay = 0;

  Object.entries(attendance).forEach(([dateStr, record]) => {
    const d = new Date(dateStr);
    if (d.getFullYear() === year && d.getMonth() === month && record.status === 'mesaide') {
      totalOvertimeHours += record.overtimeHours || 0;
      totalOvertimePay += calcOvertimePay(dateStr, record.overtimeHours || 0, settings);
    }
  });

  return {
    totalOvertimeHours,
    totalOvertimePay,
    monthlySalary: settings.monthlySalary,
    deductions: 0,
    netSalary: settings.monthlySalary + totalOvertimePay,
  };
}

export function calcNoticePay(monthlySalary, yearsWorked) {
  let weeks = 2;
  if (yearsWorked >= 6) weeks = 8;
  else if (yearsWorked >= 3) weeks = 6;
  else if (yearsWorked >= 1.5) weeks = 4;
  return (monthlySalary / 4) * weeks;
}
