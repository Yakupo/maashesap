import { useState } from 'react';
import {
  format, startOfMonth, endOfMonth, eachDayOfInterval,
  getDay, isSameDay, addMonths, subMonths
} from 'date-fns';
import { tr } from 'date-fns/locale';
import { useStore } from './utils/useStore';
import { calcMonthSummary } from './utils/calculations';
import DayModal from './components/DayModal';
import SettingsModal from './components/SettingsModal';

const DAY_LABELS = ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'];

function fmt(n) {
  return new Intl.NumberFormat('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n);
}

function getMondayIndex(date) {
  const d = getDay(date);
  return d === 0 ? 6 : d - 1;
}

export default function App() {
  const { settings, attendance, saveSettings, saveDay, deleteDay } = useStore();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(null);
  const [showSettings, setShowSettings] = useState(false);

  const today = new Date();
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const days = eachDayOfInterval({ start: startOfMonth(currentDate), end: endOfMonth(currentDate) });
  const firstDayOffset = getMondayIndex(days[0]);
  const summary = calcMonthSummary(year, month, attendance, settings);

  function dateKey(date) { return format(date, 'yyyy-MM-dd'); }
  function getDayRecord(date) { return attendance[dateKey(date)]; }
  function isWeekend(date) { const d = getDay(date); return d === 0 || d === 6; }

  function handleSaveDay(record) { saveDay(dateKey(selectedDate), record); setSelectedDate(null); }
  function handleDeleteDay() { deleteDay(dateKey(selectedDate)); setSelectedDate(null); }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col items-center py-4 px-2">
      <div className="w-full max-w-sm">

        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm p-4 mb-4">
          <div className="flex items-center justify-between mb-4">
            <button onClick={() => setCurrentDate(subMonths(currentDate, 1))}
              className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-300 text-xl font-bold">
              ‹
            </button>
            <span className="font-bold text-gray-800 dark:text-gray-100 text-lg">
              {format(currentDate, 'MMMM yyyy', { locale: tr }).replace(/^\w/, c => c.toUpperCase())}
            </span>
            <button onClick={() => setCurrentDate(addMonths(currentDate, 1))}
              className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-300 text-xl font-bold">
              ›
            </button>
            <button onClick={() => setShowSettings(true)}
              className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 ml-2 text-base">
              ⚙️
            </button>
          </div>

          <div className="grid grid-cols-7 mb-1">
            {DAY_LABELS.map((d, i) => (
              <div key={d} className={`text-center text-xs font-semibold py-1 ${i >= 5 ? 'text-red-400' : 'text-gray-400 dark:text-gray-500'}`}>{d}</div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-1">
            {Array.from({ length: firstDayOffset }).map((_, i) => <div key={`e-${i}`} />)}
            {days.map(date => {
              const record = getDayRecord(date);
              const isToday = isSameDay(date, today);
              const weekend = isWeekend(date);
              return (
                <button key={dateKey(date)} onClick={() => setSelectedDate(date)}
                  className={`flex flex-col items-center justify-center rounded-xl py-1.5 text-xs transition-all
                    ${isToday ? 'ring-2 ring-yellow-400 ring-offset-1' : ''}
                    ${record ? 'bg-blue-100 dark:bg-blue-900/40' : 'bg-blue-50 dark:bg-gray-700/50'}
                    hover:bg-blue-200 dark:hover:bg-blue-800/50`}>
                  <span className={`font-semibold text-sm leading-none ${weekend ? 'text-red-500' : 'text-gray-700 dark:text-gray-200'}`}>
                    {format(date, 'd')}
                  </span>
                  {record && (
                    <span className={`text-[10px] mt-0.5 font-medium ${
                      record.status === 'mesaide' ? 'text-blue-600 dark:text-blue-400' :
                      record.status === 'izinli' ? 'text-green-600' : 'text-red-500'}`}>
                      {record.status === 'mesaide' ? `${record.overtimeHours}s` : record.status === 'izinli' ? 'İzin' : 'Dev.'}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-3">
          {[
            { label: 'Aylık Maaş', value: `₺${fmt(summary.monthlySalary)}`, color: 'text-gray-800 dark:text-gray-100' },
            { label: 'Mesai Ücreti', value: `+₺${fmt(summary.totalOvertimePay)}`, color: 'text-green-500' },
            { label: 'Kesintiler', value: `-₺${fmt(summary.deductions)}`, color: 'text-red-500' },
            { label: 'Net Ücret', value: `₺${fmt(summary.netSalary)}`, color: 'text-blue-600 dark:text-blue-400' },
          ].map(card => (
            <div key={card.label} className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm">
              <div className="text-xs text-gray-400 dark:text-gray-500 mb-1">{card.label}</div>
              <div className={`text-lg font-bold ${card.color}`}>{card.value}</div>
            </div>
          ))}
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl px-4 py-3 shadow-sm text-center">
          <span className="text-sm text-gray-500 dark:text-gray-400">
            Toplam Mesai: <strong className="text-gray-700 dark:text-gray-200">{summary.totalOvertimeHours} saat</strong>
          </span>
        </div>
      </div>

      {selectedDate && (
        <DayModal date={selectedDate} record={getDayRecord(selectedDate)}
          onSave={handleSaveDay} onDelete={handleDeleteDay} onClose={() => setSelectedDate(null)} />
      )}
      {showSettings && (
        <SettingsModal settings={settings} onSave={saveSettings} onClose={() => setShowSettings(false)} />
      )}
    </div>
  );
}
