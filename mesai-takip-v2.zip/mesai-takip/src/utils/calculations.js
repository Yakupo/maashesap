import { getHolidayInfo } from './holidays';

export function calcHourlyRate(monthlySalary, dailyWorkHours) {
  return Number(monthlySalary) / (30 * Number(dailyWorkHours));
}

export function calcOvertimePay(dateStr, hours, status, settings) {
  const date = new Date(dateStr);
  const day = date.getDay();
  const hourlyRate = calcHourlyRate(settings.monthlySalary, settings.dailyWorkHours);

  let multiplier;
  if (status === 'bayram_mesai') {
    multiplier = Number(settings.holidayMultiplier) || 2;
  } else if (day === 6) {
    multiplier = Number(settings.saturdayMultiplier);
  } else if (day === 0) {
    multiplier = Number(settings.sundayMultiplier);
  } else {
    multiplier = Number(settings.weekdayMultiplier);
  }

  return Number(hours) * hourlyRate * multiplier;
}

export function calcMonthSummary(year, month, attendance, settings) {
  let totalOvertimeHours = 0;
  let totalOvertimePay = 0;
  let totalDeductions = 0;

  const dailyRate = Number(settings.monthlySalary) / 30;

  Object.entries(attendance).forEach(([dateStr, record]) => {
    const d = new Date(dateStr);
    if (d.getFullYear() === year && d.getMonth() === month) {
      if (record.status === 'mesaide' || record.status === 'bayram_mesai') {
        totalOvertimeHours += Number(record.overtimeHours) || 0;
        totalOvertimePay += calcOvertimePay(dateStr, record.overtimeHours || 0, record.status, settings);
      } else if (record.status === 'devamsiz') {
        totalDeductions += dailyRate;
      }
    }
  });

  const salary = Number(settings.monthlySalary);
  return {
    totalOvertimeHours,
    totalOvertimePay,
    monthlySalary: salary,
    deductions: totalDeductions,
    netSalary: salary + totalOvertimePay - totalDeductions,
  };
}

export function calcNoticePay(monthlySalary, yearsWorked) {
  let weeks = 2;
  if (yearsWorked >= 6) weeks = 8;
  else if (yearsWorked >= 3) weeks = 6;
  else if (yearsWorked >= 1.5) weeks = 4;
  return (Number(monthlySalary) / 4) * weeks;
}
